#ifndef _PROGGIE_H_
#define _PROGGIE_H_

int one();
int two();
int three();

#endif
