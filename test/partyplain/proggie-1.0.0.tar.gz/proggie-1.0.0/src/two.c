#include "proggie.h"

int two()
{
    return 2;
}


