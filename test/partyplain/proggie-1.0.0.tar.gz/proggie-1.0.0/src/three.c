#include "proggie.h"

int three()
{
    return 3;
}



