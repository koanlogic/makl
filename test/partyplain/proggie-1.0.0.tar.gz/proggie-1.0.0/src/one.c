#include "proggie.h"

int one()
{
    return 1;
}

int main()
{
    return one() + two() + three();
}
