/*
 * $Id$
 *
 * Sample 3rd party package.
 */

const char *party_test(void);

const char *party_test()
{
    return "party_test()";
}
